package net.bluetoothviewer.application;

public class BluetoothViewerFullApplication extends BluetoothViewerApplication {

    @Override
    public boolean isLiteVersion() {
        return false;
    }

}
