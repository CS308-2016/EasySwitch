package net.bluetoothviewer.application;

import android.app.Application;

public abstract class BluetoothViewerApplication extends Application {

    public abstract boolean isLiteVersion();
}
