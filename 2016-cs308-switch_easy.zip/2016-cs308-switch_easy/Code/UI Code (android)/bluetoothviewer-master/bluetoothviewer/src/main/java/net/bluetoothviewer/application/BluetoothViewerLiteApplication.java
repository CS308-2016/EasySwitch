package net.bluetoothviewer.application;

public class BluetoothViewerLiteApplication extends BluetoothViewerApplication {

    @Override
    public boolean isLiteVersion() {
        return true;
    }

}
