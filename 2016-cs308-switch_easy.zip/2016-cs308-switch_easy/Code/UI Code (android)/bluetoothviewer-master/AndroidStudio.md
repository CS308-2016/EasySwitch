Android Studio
==============
I'm still learning to work with Android Studio. This is my cheat sheet.


Mac OS X
--------
Esc                 switch to editor
Cmd Shift a         find action by name
Cmd o               open class
Cmd Shift o         open file
Cmd Option l        reformat code
Control Tab         switch between editor tabs
Control o           override methods
Option /            expand word
