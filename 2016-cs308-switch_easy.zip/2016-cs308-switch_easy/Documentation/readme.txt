Place the presentaion and report in their respective folder.


youtube links for the videos - 
https://youtu.be/mXtBF4lwrsI
https://youtu.be/oxdMz2wKyVo