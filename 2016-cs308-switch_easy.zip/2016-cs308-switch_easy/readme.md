Project Name:
Switch Easy

Team Members:
1. Ch Nitish Chandra (120050071)
2. D Saicharan (120050060)
3. T P Varun (120050077)
4. Siddhanth R (120100006)

Project Description:
 
We propose an idea to control the home appliances with a remote without changing their internal circuitry. We achieve this by controlling the switch board that controls the appliances. We mount a box on the switch board and the box controls the switches. We arrange things such that a remote can be used to talk to the box.

