Group A 
Name: 120050060, 120100006 


Group B
 Name: 120050071, 120050077




Added a well documented and commented code of your experiments in the respective folders.
